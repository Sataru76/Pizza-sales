
SELECT * FROM pizza_sales